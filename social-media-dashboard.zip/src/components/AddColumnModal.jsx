import React, { useState } from 'react';

const AddColumnModal = ({ onClose, onAdd }) => {
  const [selectedType, setSelectedType] = useState('Home');
  
  const columnTypes = ['Home', 'Mentions', 'Search', 'Lists', 'Trending', 'Bookmarks'];
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd(selectedType);
  };
  
  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h3>Add New Column</h3>
          <button className="close-btn" onClick={onClose}>&times;</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="column-type">Column Type:</label>
            <select 
              id="column-type"
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
            >
              {columnTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          
          <div className="modal-footer">
            <button type="button" className="cancel-btn" onClick={onClose}>Cancel</button>
            <button type="submit" className="add-btn">Add Column</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddColumnModal;
